
"particle minecraft:entity_effect ~ ~ ~ 0.9960784313725490196078431372549 0.9921568627450980392156862745098 0.01568627451 1 0 force @p"

def convert(string):
    out = ""
    original = list(string.split(" "))
    if len(original) != 12:
        raise Exception("Invalid input")
    for i,num in enumerate(original):
        if 5 <= i <= 7:
            original[i] = float(num)
            original[i] = str(num)

    colors = original[5:8]
    colors = [float(i) for i in colors]

    out += " ".join(original[0:2]) + "{color:[" + str(float(colors[0])) + ", " + str(float(colors[1])) + ", " + str(float(colors[2])) + ", 1.0]} " + " ".join(original[2:5]) + " 0 0 0 " + " ".join(original[8:])

    return out

def main():
    user_data = input("Enter a value or 'q' to quit: ")
    while user_data != 'q':
        try:
            print("\n\nConverted\n" + convert(user_data))
        except Exception as e:
            print(e)
        user_data = input("Enter a value or 'q' to quit: ")
main()