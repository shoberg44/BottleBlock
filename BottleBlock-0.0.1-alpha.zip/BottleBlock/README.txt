What is this?

This datapack adds a bartender that will give you various strange soups to drink

Debug Codes (? = What happened? | @ = What do I do/implications | > = notes/more)
    player uuid fail
        ? Player uuids are being initalized but scores are already detected, repair was attemped by default.
        @ Common error, no action needed. Just be aware some player data might be lost or de-synced in rare cases.
            if your worried, make sure no one is under any bb effect and make sure everybody has all their stuff. Then update the datapack.
        > Will not detect player name changes (as of now). Be aware changing your name while the datapack is storing info could de-sync and lose that info
    -
/\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\/

What are the soups

The bartender will first give you a random catagory of soup then a random soup from that catagory
Small 70
Strong 30

Small Non-Phisical
    extreme turtle master
    nausia
    hungry
    you hit you head and it hurts now
    you go invisable when you sneak
    when you jump, you look at something random
<>  dude, stop looking at my balls
    look at every arrow
    scitofrenic - plays sound behind
    fake warden - (maybe real warden in higher teirs) / oaisis warden (no AI)
    potion effects
    salt throw

Small Phisical
    you throw up particles + sound
    for every 1-20 levels, a fire spawns on you
    gobshite(s) spawns
    you float
    you go into boat

Strong Non-Phisical
<>  you blink
    stone triping - trip on every button
    you throw up items - sound
    you go blind
    overwhelming sounds, various sounds will start to play thoughout the effect, eventally, all overlapping. Perhaps triggered by something
    balls - you cant walk
Strong Phisical
    you FLOAT
<>  clumsy - you drop a rand item every _(30)_ sec
<>  universal anger - Bee, Cave Spider, Diamond Chicken, Dolphin, Enderman, Goat, Iron Golem, Llama, Panda, Piglin, Polar Bear, Skeleton Horse, Spider, Wolf, Zombified Piglin
    alternate dimension
    fighting words - players will try and harm you
    jew - hellj
    enderman pick you up
    shit pants - grass goes to podzale
    vampire 

Developer Notes - Ignore this

uncharacterized
<>  enderman spawn around you angered and disappear as they try and attack
    cold feet - forces frost walker

    Crashing shore island
    Mountain range
    Fast river
    Swirl hole in ocean
    Low power mode. No vision and/or black screen when standing still
    black out -> tp
    parrot dance
    

required systems
    
    anger protocal
    rotation to motion
    smooth look transform
    ride protocal
    shader timed fade in and out + color fade in channel 2
    dimension

/\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\/